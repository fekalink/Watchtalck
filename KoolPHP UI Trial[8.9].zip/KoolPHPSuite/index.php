<?php 
	header("Location: Examples/KoolPHPSuite/index.php");
?>
